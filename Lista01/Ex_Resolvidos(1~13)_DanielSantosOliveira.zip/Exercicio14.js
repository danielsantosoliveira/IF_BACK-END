/**
 * 14 – Criar um programa que leia uma matriz 3x4 (3 linhas e 4 colunas). Exibir a matriz informada
    e sua Transposta.
 */

