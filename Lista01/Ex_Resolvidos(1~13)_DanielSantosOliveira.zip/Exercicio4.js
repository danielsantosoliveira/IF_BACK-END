/**
 * Criar um programa que escreva os números de 1 a 1000 na tela.
 */

for (let index = 1; index <= 1000; index++)  console.log(index)